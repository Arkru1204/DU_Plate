# animated menu indicator — week 27/52

A Pen created on CodePen.io. Original URL: [https://codepen.io/knyttneve/pen/LKrGBy](https://codepen.io/knyttneve/pen/LKrGBy).

animated menu indicator — week 27/52